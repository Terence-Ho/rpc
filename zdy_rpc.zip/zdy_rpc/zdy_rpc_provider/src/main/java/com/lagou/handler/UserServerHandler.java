package com.lagou.handler;

import com.lagou.RpcRequest;
import com.lagou.service.UserServiceImpl;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;

public class UserServerHandler extends ChannelInboundHandlerAdapter {

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        RpcRequest rpcRequest = (RpcRequest) msg;
//        rpcRequest.setRequestId("123456");
//        rpcRequest.setClassName("UserService");
//        rpcRequest.setMethodName("sayHello");
//        Object[] params = new Object[]{"are you ok?"};
//        rpcRequest.setParameters(params);
//        rpcRequest.setParameterTypes(new Class<?>[]{params[0].getClass()});

        UserServiceImpl userService = new UserServiceImpl();
        String result = userService.sayHello(rpcRequest);
        System.out.println("这里是服务端里面的 channelRead 返回的结果：" + result);
        ctx.writeAndFlush(result);
    }
}
