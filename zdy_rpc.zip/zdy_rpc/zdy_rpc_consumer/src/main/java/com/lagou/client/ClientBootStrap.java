package com.lagou.client;

import com.lagou.RpcRequest;
import com.lagou.service.UserService;

public class ClientBootStrap {

    public static void main(String[] args) throws InterruptedException {
        RpcConsumer rpcConsumer = new RpcConsumer();
        RpcRequest rpcRequest = new RpcRequest();
        rpcRequest.setRequestId("123456");
        rpcRequest.setClassName("UserService");
        rpcRequest.setMethodName("sayHello");
        Object[] params = new Object[]{"are you ok?"};
        rpcRequest.setParameters(params);
        rpcRequest.setParameterTypes(new Class<?>[]{params[0].getClass()});

        UserService proxy = (UserService) rpcConsumer.createProxy(UserService.class, rpcRequest);
        while (true) {
            Thread.sleep(2000);
            String s = proxy.sayHello(rpcRequest);
            System.out.println("这是服务端返回的结果：" + s);
        }
    }
}
