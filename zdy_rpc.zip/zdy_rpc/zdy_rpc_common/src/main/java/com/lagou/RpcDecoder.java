package com.lagou;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ReplayingDecoder;

import java.util.List;

public class RpcDecoder extends ReplayingDecoder {
    private Class<?> clazz;
    private Serializer serializer;

    public RpcDecoder(Class<?> clazz, Serializer serializer) {
        this.clazz = clazz;
        this.serializer = serializer;
    }

    @Override
    protected void decode(ChannelHandlerContext ctx, ByteBuf buf, List<Object> out) throws Exception {
        int length = buf.readInt();
        byte[] content = new byte[length];
        buf.readBytes(content);
        if (length == 7) {
            out.add(new String(content,"UTF-8"));
        } else {
            Object deserialize = serializer.deserialize(clazz, content);
            out.add(deserialize);
        }
    }
}
