package com.lagou;

import com.alibaba.fastjson.JSON;

import java.io.IOException;

public class JSONSerializer implements Serializer {

    /**
     * 序列化
     *
     * @param object
     * @return
     * @throws IOException
     */
    public byte[] serialize(Object object) throws IOException {
        return JSON.toJSONBytes(object);
    }

    /**
     * 反序列化
     *
     * @param clazz
     * @param bytes
     * @param <T>
     * @return
     * @throws IOException
     */
    public <T> T deserialize(Class<T> clazz, byte[] bytes) throws IOException {
        return JSON.parseObject(bytes, clazz);
    }
}
