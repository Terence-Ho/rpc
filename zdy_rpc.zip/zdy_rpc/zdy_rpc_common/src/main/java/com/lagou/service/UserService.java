package com.lagou.service;

import com.lagou.RpcRequest;

public interface UserService {

    public String sayHello(RpcRequest request);
}
